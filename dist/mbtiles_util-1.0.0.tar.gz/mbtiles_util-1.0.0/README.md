# Python Utilities for working with MBTiles
## mbtile2folder: 
- Convert MBTiles file to folder:  ``` mbtiles2folder -i -o ```\
    * -i: input mbtiles filename, -o: output folder
 